package main

import (
	"fmt"
	"os"

	"github.com/solace/solution-manager/go-agent/internal/config"
)

func main() {
	cfg, err := config.Load(os.Args)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error loading config: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Starting sm-agent with config: %+v\n", cfg)
}
