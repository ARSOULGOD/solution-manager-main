module github.com/solace/solution-manager/go-agent

go 1.26.4
